//
//  AppDelegate.h
//  CustomViewAnimation
//
//  Created by Md. Milan Mia on 10/5/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

